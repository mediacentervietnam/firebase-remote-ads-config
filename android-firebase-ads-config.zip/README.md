# Android Firebase Ads Config SDK

Ready-to-use library.