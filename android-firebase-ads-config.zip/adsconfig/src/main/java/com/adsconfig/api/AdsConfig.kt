package com.adsconfig.api

data class AdUnitConfig(
    val banner: String,
    val interstitial: String,
    val rewarded: String
)

data class FrequencyCap(
    val rewarded: Int,
    val interstitial: Int
)

data class CooldownConfig(
    val rewarded: Int,
    val interstitial: Int
)

data class AdsConfig(
    val adsEnabled: Boolean,
    val primaryNetwork: AdsNetwork,
    val fallbackNetwork: AdsNetwork,
    val admob: AdUnitConfig,
    val pangle: AdUnitConfig,
    val frequencyCap: FrequencyCap,
    val cooldown: CooldownConfig
)
