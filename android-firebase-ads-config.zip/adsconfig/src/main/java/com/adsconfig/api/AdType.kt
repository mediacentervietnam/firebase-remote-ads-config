package com.adsconfig.api

enum class AdType {
    BANNER, INTERSTITIAL, REWARDED
}
