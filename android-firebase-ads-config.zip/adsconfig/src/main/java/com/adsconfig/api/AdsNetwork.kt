package com.adsconfig.api

enum class AdsNetwork {
    ADMOB, PANGLE, GAM
}
