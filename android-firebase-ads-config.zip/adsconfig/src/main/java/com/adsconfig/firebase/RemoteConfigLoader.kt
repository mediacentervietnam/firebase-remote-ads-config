package com.adsconfig.firebase

import com.google.firebase.remoteconfig.ktx.remoteConfig
import com.google.firebase.ktx.Firebase
import org.json.JSONObject

object RemoteConfigLoader {

    fun load(onResult: (JSONObject) -> Unit) {
        val rc = Firebase.remoteConfig
        rc.fetchAndActivate().addOnCompleteListener {
            onResult(JSONObject(rc.getString("ads_config")))
        }
    }
}
