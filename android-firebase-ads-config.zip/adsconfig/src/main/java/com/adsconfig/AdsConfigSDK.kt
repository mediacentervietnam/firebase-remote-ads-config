package com.adsconfig

import android.app.Application
import com.adsconfig.api.*
import com.adsconfig.core.*
import com.adsconfig.firebase.RemoteConfigLoader
import org.json.JSONObject

object AdsConfigSDK {

    fun init(app: Application, onReady: () -> Unit) {
        RemoteConfigLoader.load { json ->
            AdsConfigManager.config = parse(json)
            AdsConfigManager.engine = AdsDecisionEngine(AdsConfigManager.config)
            onReady()
        }
    }

    fun canShowAd(type: AdType): Boolean =
        AdsConfigManager.engine.canShow(type)

    fun onAdShown(type: AdType) =
        FrequencyLimiter.onShown(type)

    fun getAdUnitId(type: AdType): String {
        val cfg = AdsConfigManager.config
        val unit = if (cfg.primaryNetwork == AdsNetwork.ADMOB) cfg.admob else cfg.pangle
        return when (type) {
            AdType.BANNER -> unit.banner
            AdType.INTERSTITIAL -> unit.interstitial
            AdType.REWARDED -> unit.rewarded
        }
    }

    private fun parse(json: JSONObject): AdsConfig {
        fun adUnit(o: JSONObject) =
            AdUnitConfig(o.getString("banner"), o.getString("interstitial"), o.getString("rewarded"))

        return AdsConfig(
            json.getBoolean("ads_enabled"),
            AdsNetwork.valueOf(json.getString("primary_network").uppercase()),
            AdsNetwork.valueOf(json.getString("fallback_network").uppercase()),
            adUnit(json.getJSONObject("admob")),
            adUnit(json.getJSONObject("pangle")),
            FrequencyCap(
                json.getJSONObject("frequency_cap").getInt("rewarded"),
                json.getJSONObject("frequency_cap").getInt("interstitial")
            ),
            CooldownConfig(
                json.getJSONObject("cooldown_seconds").getInt("rewarded"),
                json.getJSONObject("cooldown_seconds").getInt("interstitial")
            )
        )
    }
}
