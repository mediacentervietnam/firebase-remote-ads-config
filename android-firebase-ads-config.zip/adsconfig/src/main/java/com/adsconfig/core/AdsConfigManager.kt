package com.adsconfig.core

import com.adsconfig.api.AdsConfig

object AdsConfigManager {
    lateinit var config: AdsConfig
    lateinit var engine: AdsDecisionEngine
}
