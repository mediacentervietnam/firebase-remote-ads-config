package com.adsconfig.core

import com.adsconfig.api.*

class AdsDecisionEngine(private val config: AdsConfig) {

    fun canShow(type: AdType): Boolean {
        if (!config.adsEnabled) return false

        val cap = when (type) {
            AdType.REWARDED -> config.frequencyCap.rewarded
            else -> config.frequencyCap.interstitial
        }

        val cooldown = when (type) {
            AdType.REWARDED -> config.cooldown.rewarded
            else -> config.cooldown.interstitial
        }

        return FrequencyLimiter.canShow(type, cap, cooldown)
    }
}
