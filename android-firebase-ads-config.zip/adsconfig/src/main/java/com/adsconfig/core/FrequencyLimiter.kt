package com.adsconfig.core

import com.adsconfig.api.AdType

object FrequencyLimiter {
    private val showCount = mutableMapOf<AdType, Int>()
    private val lastShowTime = mutableMapOf<AdType, Long>()

    fun canShow(type: AdType, cap: Int, cooldown: Int): Boolean {
        val count = showCount[type] ?: 0
        val last = lastShowTime[type] ?: 0
        val now = System.currentTimeMillis()

        if (count >= cap) return false
        if (now - last < cooldown * 1000) return false
        return true
    }

    fun onShown(type: AdType) {
        showCount[type] = (showCount[type] ?: 0) + 1
        lastShowTime[type] = System.currentTimeMillis()
    }
}
